SELECT Count(*)
FROM Users