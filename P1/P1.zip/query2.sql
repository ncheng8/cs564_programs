SELECT Count(*)
FROM Users
WHERE Users.location = "New York"